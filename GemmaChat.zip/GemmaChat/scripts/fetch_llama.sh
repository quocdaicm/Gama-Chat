#!/bin/bash
# Tải llama.xcframework (bản dựng sẵn của llama.cpp) về thư mục Frameworks/.
set -euo pipefail
TAG="b6102"
ROOT="${SRCROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
DEST="$ROOT/Frameworks"
if [ -f "$DEST/llama.xcframework/Info.plist" ]; then
  echo "llama.xcframework đã có"; exit 0
fi
mkdir -p "$DEST"
TMP="$(mktemp -d)"
URL="https://github.com/ggml-org/llama.cpp/releases/download/$TAG/llama-$TAG-xcframework.zip"
echo "Tải $URL"
curl -fL --retry 3 --retry-delay 2 -o "$TMP/llama.zip" "$URL"
unzip -q "$TMP/llama.zip" -d "$TMP/x"
FW="$(find "$TMP/x" -maxdepth 4 -name 'llama.xcframework' -type d | head -1)"
if [ -z "$FW" ]; then echo "Không thấy llama.xcframework trong file zip"; exit 1; fi
rm -rf "$DEST/llama.xcframework"
cp -R "$FW" "$DEST/"
rm -rf "$TMP"
echo "Xong: $DEST/llama.xcframework"
