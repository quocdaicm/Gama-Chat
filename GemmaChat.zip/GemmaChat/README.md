# Gemma Chat (iOS)
AI Gemma 3n E2B chạy offline trên iPhone: chat chữ, nhập giọng nói tiếng Việt, đọc to câu trả lời,
gửi ảnh (OCR + nhận diện cảnh bằng Apple Vision) và tệp (txt, md, csv, json, code, pdf, docx, xlsx, pptx, rtf; PDF scan đọc bằng OCR), lưu lịch sử, tải mô hình trong app (có tạm dừng/tiếp tục) hoặc chọn file .gguf từ Files.

## Build bằng GitHub Actions
1. Đưa toàn bộ thư mục lên một repo GitHub (nhánh main).
2. Tab Actions → "Build IPA" → Run workflow.
3. Tải artifact `GemmaChat-ipa` → ký/cài bằng công cụ sideload như các app trước.
Nếu build lỗi, tải artifact `build-log` gửi lại để sửa.

## Ghi chú
- Runtime: llama.cpp (SwiftPM, nhánh master) + file GGUF Gemma 3n E2B Q4_K_M từ Hugging Face (unsloth).
- Cần iPhone RAM ≥ 6 GB (khuyến nghị iPhone 15 Pro trở lên).

- Ảnh: AI không nhìn trực tiếp ảnh; app đọc chữ và nhận diện vật thể rồi đưa kết quả cho AI.
- Ngữ cảnh 8192 token; tệp dài bị cắt bớt khoảng 10.000 ký tự mỗi lượt.
