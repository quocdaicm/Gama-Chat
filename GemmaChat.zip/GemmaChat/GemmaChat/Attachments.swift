import Foundation
import UIKit
import Vision
import PDFKit
import Compression

struct Attachment: Identifiable, Codable, Equatable {
    var id = UUID()
    var kind: String      // "image" | "file"
    var name: String
    var text: String      // nội dung đã trích xuất / kết quả phân tích ảnh
    var thumb: Data? = nil
}

extension UIImage {
    /// Xoay ảnh về đúng chiều và thu nhỏ để phân tích nhanh.
    func normalized(maxDim: CGFloat) -> UIImage {
        let scale = min(1, maxDim / max(size.width, size.height))
        let target = CGSize(width: size.width * scale, height: size.height * scale)
        let fmt = UIGraphicsImageRendererFormat(); fmt.scale = 1
        return UIGraphicsImageRenderer(size: target, format: fmt).image { _ in
            self.draw(in: CGRect(origin: .zero, size: target))
        }
    }
}

// MARK: - Phân tích ảnh bằng Apple Vision (OCR + nhận diện cảnh)
enum ImageAnalyzer {
    static func analyze(_ image: UIImage) async -> String {
        await Task.detached(priority: .userInitiated) { analyzeSync(image) }.value
    }

    static func ocr(_ cg: CGImage) -> String {
        let req = VNRecognizeTextRequest()
        req.recognitionLevel = .accurate
        req.usesLanguageCorrection = true
        req.automaticallyDetectsLanguage = true
        try? VNImageRequestHandler(cgImage: cg, options: [:]).perform([req])
        return (req.results ?? []).compactMap { $0.topCandidates(1).first?.string }.joined(separator: "\n")
    }

    static func analyzeSync(_ image: UIImage) -> String {
        guard let cg = image.cgImage else { return "" }
        let cls = VNClassifyImageRequest()
        try? VNImageRequestHandler(cgImage: cg, options: [:]).perform([cls])
        let labels = (cls.results ?? []).filter { $0.confidence > 0.35 }.prefix(6).map { $0.identifier }
        let text = ocr(cg).trimmingCharacters(in: .whitespacesAndNewlines)
        var out = ""
        if !text.isEmpty { out += "Chữ đọc được trong ảnh:\n\(text)\n" }
        if !labels.isEmpty { out += "Vật thể/cảnh nhận diện được (tiếng Anh): \(labels.joined(separator: ", "))\n" }
        if out.isEmpty { out = "(không đọc được chữ hay nhận diện được nội dung rõ ràng)" }
        return out
    }
}

// MARK: - Đọc tệp
enum FileError: LocalizedError {
    case unsupported(String), empty, tooBig
    var errorDescription: String? {
        switch self {
        case .unsupported(let e): return "Chưa đọc được định dạng .\(e). Hãy xuất ra PDF hoặc TXT."
        case .empty: return "Tệp không có nội dung chữ."
        case .tooBig: return "Tệp quá lớn (tối đa 30 MB)."
        }
    }
}

enum FileReader {
    static let maxChars = 40_000

    static func extract(_ url: URL) async throws -> String {
        let access = url.startAccessingSecurityScopedResource()
        defer { if access { url.stopAccessingSecurityScopedResource() } }
        return try await Task.detached(priority: .userInitiated) { try extractSync(url) }.value
    }

    static func extractSync(_ url: URL) throws -> String {
        let size = (try? url.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0
        if size > 30_000_000 { throw FileError.tooBig }
        let ext = url.pathExtension.lowercased()
        var text: String
        switch ext {
        case "pdf": text = pdfText(url)
        case "docx": text = try officeText(url, kind: .docx)
        case "pptx": text = try officeText(url, kind: .pptx)
        case "xlsx": text = try officeText(url, kind: .xlsx)
        case "rtf":
            let a = try? NSAttributedString(url: url, options: [:], documentAttributes: nil)
            text = a?.string ?? ""
        case "doc", "xls", "ppt", "pages", "numbers", "key", "zip", "png", "jpg", "jpeg", "heic", "mp3", "mp4", "mov":
            throw FileError.unsupported(ext)
        default: text = try plainText(url, ext)
        }
        text = text.trimmingCharacters(in: .whitespacesAndNewlines)
        if text.isEmpty { throw FileError.empty }
        if text.count > maxChars { text = String(text.prefix(maxChars)) + "\n[...đã cắt bớt]" }
        return text
    }

    static func plainText(_ url: URL, _ ext: String) throws -> String {
        let data = try Data(contentsOf: url)
        if data.prefix(2000).contains(0) {
            if let s = String(data: data, encoding: .utf16), !s.isEmpty { return s }
            throw FileError.unsupported(ext.isEmpty ? "?" : ext)
        }
        return String(data: data, encoding: .utf8) ?? String(data: data, encoding: .isoLatin1) ?? ""
    }

    static func pdfText(_ url: URL) -> String {
        guard let doc = PDFDocument(url: url) else { return "" }
        let t = (doc.string ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        if t.count >= 50 { return t }
        // PDF dạng ảnh scan → OCR tối đa 8 trang
        var out = "(PDF dạng ảnh, đọc bằng OCR)\n"
        for i in 0..<min(doc.pageCount, 8) {
            guard let page = doc.page(at: i) else { continue }
            let b = page.bounds(for: .mediaBox)
            let s = 1800 / max(b.width, b.height)
            let img = page.thumbnail(of: CGSize(width: b.width * s, height: b.height * s), for: .mediaBox)
            if let cg = img.cgImage { out += "--- Trang \(i + 1) ---\n" + ImageAnalyzer.ocr(cg) + "\n" }
        }
        if doc.pageCount > 8 { out += "[chỉ đọc 8 trang đầu]" }
        return out
    }

    enum OfficeKind { case docx, pptx, xlsx }

    static func officeText(_ url: URL, kind: OfficeKind) throws -> String {
        guard let zip = ZipReader(url: url) else { throw FileError.unsupported(url.pathExtension) }
        switch kind {
        case .docx:
            guard let d = zip.read("word/document.xml") else { return "" }
            var x = String(decoding: d, as: UTF8.self)
            x = x.replacingOccurrences(of: "<w:tab/>", with: "\t").replacingOccurrences(of: "<w:br/>", with: "\n")
            return stripXML(x, paragraph: "w:p")
        case .pptx:
            let slides = zip.names.filter { $0.hasPrefix("ppt/slides/slide") && $0.hasSuffix(".xml") }
                .sorted { num($0) < num($1) }
            var out = ""
            for (i, n) in slides.enumerated() {
                guard let d = zip.read(n) else { continue }
                out += "--- Slide \(i + 1) ---\n" + stripXML(String(decoding: d, as: UTF8.self), paragraph: "a:p") + "\n"
            }
            return out
        case .xlsx:
            var shared = [String]()
            if let d = zip.read("xl/sharedStrings.xml") {
                let x = String(decoding: d, as: UTF8.self)
                shared = groups(#"<si>(.*?)</si>"#, x).map { stripXML($0[1], paragraph: "") }
            }
            let sheets = zip.names.filter { $0.hasPrefix("xl/worksheets/sheet") && $0.hasSuffix(".xml") }
                .sorted { num($0) < num($1) }.prefix(3)
            var out = ""
            for (si, n) in sheets.enumerated() {
                guard let d = zip.read(n) else { continue }
                let x = String(decoding: d, as: UTF8.self)
                out += "--- Sheet \(si + 1) ---\n"
                for row in groups(#"<row\b[^>]*>(.*?)</row>"#, x).prefix(300) {
                    var cells = [String]()
                    for c in groups(#"<c\b([^>]*?)(?:/>|>(.*?)</c>)"#, row[1]) {
                        let attrs = c[1], body = c[2]
                        let t = groups(#"\bt="([^"]*)""#, attrs).first?[1] ?? ""
                        if let v = groups(#"<v>(.*?)</v>"#, body).first?[1] {
                            if t == "s", let idx = Int(v), idx < shared.count { cells.append(shared[idx]) }
                            else { cells.append(v) }
                        } else if let s = groups(#"<t[^>]*>(.*?)</t>"#, body).first?[1] {
                            cells.append(decode(s))
                        }
                    }
                    if !cells.isEmpty { out += cells.joined(separator: " | ") + "\n" }
                }
            }
            return out
        }
    }

    static func num(_ s: String) -> Int { Int(s.filter(\.isNumber)) ?? 0 }

    static func decode(_ s: String) -> String {
        s.replacingOccurrences(of: "&lt;", with: "<").replacingOccurrences(of: "&gt;", with: ">")
         .replacingOccurrences(of: "&quot;", with: "\"").replacingOccurrences(of: "&apos;", with: "'")
         .replacingOccurrences(of: "&amp;", with: "&")
    }

    static func stripXML(_ xml: String, paragraph: String) -> String {
        var s = xml
        if !paragraph.isEmpty { s = s.replacingOccurrences(of: "</\(paragraph)>", with: "\n") }
        s = s.replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression)
        return decode(s)
    }

    static func groups(_ pattern: String, _ s: String) -> [[String]] {
        guard let re = try? NSRegularExpression(pattern: pattern, options: [.dotMatchesLineSeparators]) else { return [] }
        let ns = s as NSString
        return re.matches(in: s, range: NSRange(location: 0, length: ns.length)).map { m in
            (0..<m.numberOfRanges).map { i in
                m.range(at: i).location == NSNotFound ? "" : ns.substring(with: m.range(at: i))
            }
        }
    }
}

// MARK: - Đọc file ZIP tối giản (docx/xlsx/pptx)
final class ZipReader {
    struct Entry { let name: String; let method: Int; let csize: Int; let usize: Int; let offset: Int }
    private let b: [UInt8]
    private var entries: [String: Entry] = [:]
    var names: [String] { Array(entries.keys) }

    private func u16(_ i: Int) -> Int { Int(b[i]) | Int(b[i + 1]) << 8 }
    private func u32(_ i: Int) -> Int { u16(i) | u16(i + 2) << 16 }

    init?(url: URL) {
        guard let d = try? Data(contentsOf: url) else { return nil }
        b = [UInt8](d)
        guard b.count > 22 else { return nil }
        var eocd = -1
        var i = b.count - 22
        while i >= max(0, b.count - 65_557) {
            if b[i] == 0x50, b[i + 1] == 0x4b, b[i + 2] == 0x05, b[i + 3] == 0x06 { eocd = i; break }
            i -= 1
        }
        guard eocd >= 0 else { return nil }
        let count = u16(eocd + 10)
        var p = u32(eocd + 16)
        for _ in 0..<count {
            guard p + 46 <= b.count, u32(p) == 0x02014b50 else { break }
            let method = u16(p + 10), cs = u32(p + 20), us = u32(p + 24)
            let n = u16(p + 28), m = u16(p + 30), k = u16(p + 32), off = u32(p + 42)
            guard p + 46 + n <= b.count else { break }
            let name = String(decoding: b[(p + 46)..<(p + 46 + n)], as: UTF8.self)
            entries[name] = Entry(name: name, method: method, csize: cs, usize: us, offset: off)
            p += 46 + n + m + k
        }
        if entries.isEmpty { return nil }
    }

    func read(_ name: String) -> Data? {
        guard let e = entries[name], e.offset + 30 <= b.count, u32(e.offset) == 0x04034b50 else { return nil }
        let start = e.offset + 30 + u16(e.offset + 26) + u16(e.offset + 28)
        guard start + e.csize <= b.count else { return nil }
        let comp = Array(b[start..<(start + e.csize)])
        if e.method == 0 { return Data(comp) }
        guard e.method == 8, e.usize > 0 else { return nil }
        var out = [UInt8](repeating: 0, count: e.usize)
        let n = compression_decode_buffer(&out, out.count, comp, comp.count, nil, COMPRESSION_ZLIB)
        return n > 0 ? Data(out.prefix(n)) : nil
    }
}
