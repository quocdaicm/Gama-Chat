import SwiftUI
import PhotosUI
import UniformTypeIdentifiers

struct RootView: View {
    @StateObject private var vm = ChatVM()
    var body: some View {
        Group {
            switch vm.phase {
            case .needModel: SetupView(vm: vm)
            case .loading:
                ZStack {
                    Theme.backdrop.ignoresSafeArea()
                    VStack(spacing: 22) {
                        PulsingLogo()
                        Text("Đang nạp mô hình vào bộ nhớ…").foregroundStyle(.secondary)
                    }
                }
            case .failed(let msg):
                ZStack {
                    Theme.backdrop.ignoresSafeArea()
                    VStack(spacing: 16) {
                        Image(systemName: "exclamationmark.triangle.fill").font(.largeTitle).foregroundStyle(.orange)
                        Text(msg).multilineTextAlignment(.center).padding(.horizontal)
                        Button("Thử nạp lại") { vm.loadModel() }.buttonStyle(GradientButtonStyle()).padding(.horizontal, 40)
                        Button("Xóa mô hình & tải lại", role: .destructive) { vm.deleteModel() }
                    }
                }
            case .ready: ChatView(vm: vm)
            }
        }
        .tint(Theme.violet)
    }
}

// MARK: - Màn tải mô hình
struct SetupView: View {
    @ObservedObject var vm: ChatVM
    @ObservedObject var dl: ModelDownloader
    @State private var showSettings = false
    @State private var picking = false

    init(vm: ChatVM) { self.vm = vm; self.dl = vm.downloader }

    private func row(_ icon: String, _ title: String, _ value: String) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon).frame(width: 26).foregroundStyle(Theme.violet)
            Text(title).foregroundStyle(.secondary)
            Spacer()
            Text(value).fontWeight(.medium)
        }
    }

    private var progressBar: some View {
        GeometryReader { g in
            ZStack(alignment: .leading) {
                Capsule().fill(Color(.tertiarySystemFill))
                Capsule().fill(Theme.gradient).frame(width: max(10, g.size.width * dl.progress))
            }
        }.frame(height: 10)
    }

    var body: some View {
        NavigationStack {
            ZStack {
                Theme.backdrop.ignoresSafeArea()
                VStack(spacing: 20) {
                    Spacer()
                    LogoView(size: 110)
                    Text("Gemma Chat").font(.system(size: 34, weight: .bold, design: .rounded))
                    Text("Trợ lý AI chạy ngay trên iPhone.\nTải một lần, dùng offline mãi mãi.")
                        .multilineTextAlignment(.center).foregroundStyle(.secondary)

                    VStack(spacing: 14) {
                        row("cpu", "Mô hình", "Gemma 3n E2B")
                        Divider()
                        row("externaldrive", "Dung lượng", "≈ 2,8 GB")
                        Divider()
                        row("wifi.slash", "Sau khi tải", "Chạy offline")
                    }
                    .padding(18)
                    .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                    .padding(.horizontal, 24)

                    if dl.isDownloading {
                        VStack(spacing: 10) {
                            progressBar
                            Text("\(Int(dl.progress * 100))%  •  \(ByteCountFormatter.string(fromByteCount: dl.received, countStyle: .file)) / \(ByteCountFormatter.string(fromByteCount: dl.total, countStyle: .file))")
                                .font(.footnote).foregroundStyle(.secondary).monospacedDigit()
                            HStack(spacing: 12) {
                                Button("Tạm dừng") { dl.pause() }.buttonStyle(.bordered)
                                Button("Hủy", role: .destructive) { dl.cancel() }.buttonStyle(.bordered)
                            }
                        }.padding(.horizontal, 40)
                    } else {
                        VStack(spacing: 12) {
                            Button { vm.startDownload() } label: {
                                Label("Tải mô hình", systemImage: "arrow.down.circle.fill")
                            }.buttonStyle(GradientButtonStyle())
                            Button("Hoặc chọn file .gguf từ máy") { picking = true }.font(.subheadline)
                        }.padding(.horizontal, 40)
                    }
                    if let e = dl.error {
                        Text(e).foregroundStyle(.red).font(.footnote).multilineTextAlignment(.center).padding(.horizontal, 30)
                    }
                    Text("Nên dùng Wi-Fi và giữ app mở khi đang tải.").font(.footnote).foregroundStyle(.secondary)
                    Spacer()
                }
            }
            .toolbar { Button { showSettings = true } label: { Image(systemName: "gearshape") } }
            .sheet(isPresented: $showSettings) { SettingsView(vm: vm) }
            .fileImporter(isPresented: $picking, allowedContentTypes: [.data]) { r in
                if case .success(let u) = r { dl.importFile(u) }
            }
        }
    }
}

// MARK: - Chat
struct ChatView: View {
    @ObservedObject var vm: ChatVM
    @ObservedObject var speaker: Speaker
    @ObservedObject var rec: Recognizer
    @State private var showSettings = false
    @State private var showPhotos = false
    @State private var showCamera = false
    @State private var showFiles = false
    @State private var photoItems: [PhotosPickerItem] = []
    @FocusState private var focused: Bool

    init(vm: ChatVM) { self.vm = vm; self.speaker = vm.speaker; self.rec = vm.recognizer }

    private let suggestions: [(String, String)] = [
        ("lightbulb", "Giải thích đơn giản về trí tuệ nhân tạo"),
        ("envelope", "Viết email xin nghỉ phép lịch sự"),
        ("globe", "Dịch giúp tôi sang tiếng Anh"),
        ("list.bullet.clipboard", "Lập kế hoạch học tập 7 ngày")
    ]

    private var welcome: some View {
        VStack(spacing: 16) {
            LogoView(size: 84).padding(.top, 50)
            Text("Xin chào! Mình giúp gì được cho bạn?")
                .font(.title3.weight(.semibold)).multilineTextAlignment(.center)
            Text("AI chạy hoàn toàn trên máy bạn, không gửi dữ liệu đi đâu.")
                .font(.footnote).foregroundStyle(.secondary).multilineTextAlignment(.center)
            LazyVGrid(columns: [GridItem(.flexible(), spacing: 10), GridItem(.flexible(), spacing: 10)], spacing: 10) {
                ForEach(suggestions, id: \.1) { s in
                    Button { vm.send(s.1) } label: {
                        VStack(alignment: .leading, spacing: 8) {
                            Image(systemName: s.0).foregroundStyle(Theme.gradient)
                            Text(s.1).font(.subheadline).multilineTextAlignment(.leading).foregroundStyle(.primary)
                        }
                        .frame(maxWidth: .infinity, minHeight: 84, alignment: .topLeading)
                        .padding(12)
                        .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    }
                }
            }.padding(.top, 10)
        }.padding(.horizontal, 18)
    }

    private var messagesView: some View {
        ScrollViewReader { proxy in
            ScrollView {
                if vm.messages.isEmpty {
                    welcome
                } else {
                    LazyVStack(spacing: 14) {
                        ForEach(vm.messages) { m in Bubble(msg: m, speaker: speaker).id(m.id) }
                    }.padding(.horizontal, 14).padding(.vertical, 12)
                }
            }
            .scrollDismissesKeyboard(.interactively)
            .onChange(of: vm.messages.last?.text) { _, _ in
                if let id = vm.messages.last?.id { proxy.scrollTo(id, anchor: .bottom) }
            }
            .onChange(of: vm.messages.count) { _, _ in
                if let id = vm.messages.last?.id { withAnimation { proxy.scrollTo(id, anchor: .bottom) } }
            }
        }
    }

    private func circleIcon(_ name: String) -> some View {
        Image(systemName: name).font(.system(size: 18, weight: .semibold))
            .foregroundStyle(Theme.violet).frame(width: 40, height: 40)
            .background(Theme.violet.opacity(0.12), in: Circle())
    }

    private var canSend: Bool {
        vm.processing == 0 && (!vm.input.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || !vm.pending.isEmpty)
    }

    private var sendButton: some View {
        Button {
            if vm.isGenerating { vm.stop() } else {
                UIImpactFeedbackGenerator(style: .light).impactOccurred()
                vm.send(); focused = false
            }
        } label: {
            Image(systemName: vm.isGenerating ? "stop.fill" : "arrow.up")
                .font(.system(size: 17, weight: .bold)).foregroundStyle(.white)
                .frame(width: 40, height: 40)
                .background(Theme.gradient, in: Circle())
                .opacity(vm.isGenerating || canSend ? 1 : 0.35)
        }.disabled(!vm.isGenerating && !canSend)
    }

    private var inputBar: some View {
        VStack(spacing: 8) {
            if !vm.pending.isEmpty || vm.processing > 0 {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(vm.pending) { a in AttachChip(a: a) { vm.removePending(a) } }
                        if vm.processing > 0 { ProgressView().padding(.horizontal, 12) }
                    }
                }
            }
            HStack(alignment: .bottom, spacing: 10) {
                Menu {
                    Button { showPhotos = true } label: { Label("Chọn ảnh", systemImage: "photo") }
                    Button { showCamera = true } label: { Label("Chụp ảnh", systemImage: "camera") }
                    Button { showFiles = true } label: { Label("Chọn tệp", systemImage: "doc") }
                } label: { circleIcon("plus") }

                HStack(alignment: .bottom, spacing: 6) {
                    TextField(rec.isRecording ? "Đang nghe…" : "Nhắn cho Gemma…", text: $vm.input, axis: .vertical)
                        .lineLimit(1...5).focused($focused)
                    Button { vm.toggleMic() } label: {
                        Image(systemName: rec.isRecording ? "stop.circle.fill" : "mic.fill")
                            .font(.system(size: 20))
                            .foregroundStyle(rec.isRecording ? Color.red : Theme.violet)
                    }
                }
                .padding(.horizontal, 14).padding(.vertical, 10)
                .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 22, style: .continuous))

                sendButton
            }
        }
        .padding(.horizontal, 12).padding(.vertical, 8)
        .background(.bar)
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                messagesView
                inputBar
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    HStack(spacing: 8) {
                        LogoView(size: 26)
                        Text("Gemma Chat").font(.system(.headline, design: .rounded))
                    }
                }
                ToolbarItem(placement: .topBarLeading) {
                    Button { vm.newChat() } label: { Image(systemName: "square.and.pencil") }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button { showSettings = true } label: { Image(systemName: "gearshape") }
                }
            }
            .sheet(isPresented: $showSettings) { SettingsView(vm: vm) }
            .photosPicker(isPresented: $showPhotos, selection: $photoItems, maxSelectionCount: 4, matching: .images)
            .onChange(of: photoItems) { _, items in
                guard !items.isEmpty else { return }
                Task { await vm.addPhotos(items); photoItems = [] }
            }
            .fullScreenCover(isPresented: $showCamera) {
                CameraPicker { vm.addImage($0, name: "Ảnh chụp") }.ignoresSafeArea()
            }
            .fileImporter(isPresented: $showFiles, allowedContentTypes: [.item], allowsMultipleSelection: true) { r in
                if case .success(let urls) = r { vm.addFiles(urls) }
            }
            .alert("Không đính kèm được", isPresented: Binding(get: { vm.attachError != nil },
                                                                 set: { if !$0 { vm.attachError = nil } })) {
                Button("OK", role: .cancel) {}
            } message: { Text(vm.attachError ?? "") }
            .alert("Cần quyền micro và nhận dạng giọng nói trong Cài đặt iPhone.", isPresented: $rec.denied) {
                Button("OK", role: .cancel) {}
            }
        }
    }
}

// MARK: - Bong bóng chat
struct Bubble: View {
    let msg: ChatMessage
    @ObservedObject var speaker: Speaker
    var isUser: Bool { msg.role == "user" }

    private var userShape: UnevenRoundedRectangle {
        UnevenRoundedRectangle(topLeadingRadius: 20, bottomLeadingRadius: 20, bottomTrailingRadius: 6, topTrailingRadius: 20, style: .continuous)
    }
    private var modelShape: UnevenRoundedRectangle {
        UnevenRoundedRectangle(topLeadingRadius: 6, bottomLeadingRadius: 20, bottomTrailingRadius: 20, topTrailingRadius: 20, style: .continuous)
    }

    private var attachmentsRow: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 6) {
                ForEach(msg.attachments ?? []) { a in
                    if let d = a.thumb, let ui = UIImage(data: d) {
                        Image(uiImage: ui).resizable().scaledToFill()
                            .frame(width: 72, height: 72).clipShape(RoundedRectangle(cornerRadius: 10))
                    } else {
                        Label(a.name, systemImage: "doc.text").font(.footnote).lineLimit(1)
                            .padding(8).background(Color.black.opacity(0.15))
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                    }
                }
            }
        }
    }

    private var actions: some View {
        HStack(spacing: 18) {
            Button { speaker.speaking ? speaker.stop() : speaker.speak(msg.text) } label: {
                Image(systemName: speaker.speaking ? "speaker.slash.fill" : "speaker.wave.2.fill")
            }
            Button { UIPasteboard.general.string = msg.text } label: { Image(systemName: "doc.on.doc") }
        }.font(.footnote).foregroundStyle(.secondary)
    }

    private var content: some View {
        VStack(alignment: .leading, spacing: 8) {
            if let atts = msg.attachments, !atts.isEmpty { attachmentsRow }
            if msg.text.isEmpty { TypingDots() } else { Text(attributed) }
            if !isUser && !msg.text.isEmpty { actions }
        }
        .padding(.horizontal, 14).padding(.vertical, 10)
        .foregroundStyle(isUser ? Color.white : Color.primary)
        .textSelection(.enabled)
    }

    var body: some View {
        if isUser {
            HStack {
                Spacer(minLength: 48)
                content.background(Theme.gradient, in: userShape)
            }
        } else {
            HStack(alignment: .top, spacing: 8) {
                AvatarMark(size: 28).padding(.top, 4)
                content.background(Color(.secondarySystemBackground), in: modelShape)
                Spacer(minLength: 28)
            }
        }
    }

    var attributed: AttributedString {
        (try? AttributedString(markdown: msg.text,
            options: .init(interpretedSyntax: .inlineOnlyPreservingWhitespace))) ?? AttributedString(msg.text)
    }
}

// MARK: - Đính kèm
struct AttachChip: View {
    let a: Attachment
    let onRemove: () -> Void
    var body: some View {
        HStack(spacing: 6) {
            if let d = a.thumb, let ui = UIImage(data: d) {
                Image(uiImage: ui).resizable().scaledToFill().frame(width: 40, height: 40)
                    .clipShape(RoundedRectangle(cornerRadius: 8))
            } else {
                Image(systemName: "doc.text.fill").font(.title3).foregroundStyle(Theme.violet)
            }
            Text(a.name).font(.footnote).lineLimit(1).frame(maxWidth: 110, alignment: .leading)
            Button(action: onRemove) { Image(systemName: "xmark.circle.fill").foregroundStyle(.secondary) }
        }
        .padding(6).background(Color(.secondarySystemBackground)).clipShape(RoundedRectangle(cornerRadius: 12))
    }
}

struct CameraPicker: UIViewControllerRepresentable {
    var onImage: (UIImage) -> Void
    @Environment(\.dismiss) private var dismiss

    func makeUIViewController(context: Context) -> UIImagePickerController {
        let p = UIImagePickerController()
        p.sourceType = UIImagePickerController.isSourceTypeAvailable(.camera) ? .camera : .photoLibrary
        p.delegate = context.coordinator
        return p
    }
    func updateUIViewController(_ vc: UIImagePickerController, context: Context) {}
    func makeCoordinator() -> Coordinator { Coordinator(self) }

    final class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        let parent: CameraPicker
        init(_ p: CameraPicker) { parent = p }
        func imagePickerController(_ picker: UIImagePickerController,
                                   didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
            if let img = info[.originalImage] as? UIImage { parent.onImage(img) }
            parent.dismiss()
        }
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) { parent.dismiss() }
    }
}

// MARK: - Cài đặt
struct SettingsView: View {
    @ObservedObject var vm: ChatVM
    @Environment(\.dismiss) private var dismiss
    @AppStorage("systemPrompt") private var systemPrompt = Defaults.system
    @AppStorage("autoSpeak") private var autoSpeak = false
    @AppStorage("autoSendVoice") private var autoSendVoice = true
    @AppStorage("modelURL") private var modelURL = Defaults.modelURL
    @AppStorage("hfToken") private var hfToken = ""

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack(spacing: 14) {
                        LogoView(size: 52)
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Gemma Chat").font(.headline)
                            Text("Gemma 3n E2B • chạy offline").font(.footnote).foregroundStyle(.secondary)
                        }
                    }.padding(.vertical, 4)
                }
                Section("Giọng nói") {
                    Toggle("Tự đọc câu trả lời (tiếng Việt)", isOn: $autoSpeak)
                    Toggle("Bấm mic lần 2 là gửi luôn", isOn: $autoSendVoice)
                }
                Section("Vai trò của AI") {
                    TextEditor(text: $systemPrompt).frame(minHeight: 100)
                    Button("Khôi phục mặc định") { systemPrompt = Defaults.system }
                }
                Section("Mô hình") {
                    TextField("Link .gguf", text: $modelURL, axis: .vertical).font(.footnote)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                    SecureField("Token Hugging Face (nếu cần)", text: $hfToken)
                    if ModelStore.exists {
                        LabeledContent("Dung lượng", value: ModelStore.sizeText)
                        Button("Xóa mô hình", role: .destructive) { vm.deleteModel(); dismiss() }
                    }
                }
            }
            .navigationTitle("Cài đặt").navigationBarTitleDisplayMode(.inline)
            .toolbar { Button("Xong") { dismiss() } }
        }
    }
}
