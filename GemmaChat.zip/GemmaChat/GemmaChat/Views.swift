import SwiftUI
import PhotosUI
import UniformTypeIdentifiers

struct RootView: View {
    @StateObject private var vm = ChatVM()
    var body: some View {
        switch vm.phase {
        case .needModel: SetupView(vm: vm)
        case .loading:
            VStack(spacing: 16) { ProgressView(); Text("Đang nạp mô hình vào bộ nhớ…").foregroundStyle(.secondary) }
        case .failed(let msg):
            VStack(spacing: 16) {
                Text(msg).multilineTextAlignment(.center).padding()
                Button("Thử nạp lại") { vm.loadModel() }.buttonStyle(.borderedProminent)
                Button("Xóa mô hình & tải lại", role: .destructive) { vm.deleteModel() }
            }
        case .ready: ChatView(vm: vm)
        }
    }
}

// MARK: - Màn tải mô hình
struct SetupView: View {
    @ObservedObject var vm: ChatVM
    @ObservedObject var dl: ModelDownloader
    @State private var showSettings = false
    @State private var picking = false

    init(vm: ChatVM) { self.vm = vm; self.dl = vm.downloader }

    var body: some View {
        NavigationStack {
            VStack(spacing: 18) {
                Spacer()
                Text("Tải AI về máy").font(.largeTitle.bold())
                Text("Gemma 3n E2B (≈ 2,8 GB). Tải một lần, sau đó chạy hoàn toàn offline.")
                    .multilineTextAlignment(.center).foregroundStyle(.secondary).padding(.horizontal)
                if dl.isDownloading {
                    ProgressView(value: dl.progress).padding(.horizontal, 40)
                    Text("\(ByteCountFormatter.string(fromByteCount: dl.received, countStyle: .file)) / \(ByteCountFormatter.string(fromByteCount: dl.total, countStyle: .file))")
                        .font(.footnote).foregroundStyle(.secondary)
                    HStack {
                        Button("Tạm dừng") { dl.pause() }.buttonStyle(.bordered)
                        Button("Hủy", role: .destructive) { dl.cancel() }.buttonStyle(.bordered)
                    }
                } else {
                    Button { vm.startDownload() } label: {
                        Text("Download").font(.title3).frame(width: 200, height: 52)
                    }.buttonStyle(.borderedProminent).clipShape(Capsule())
                    Button("Hoặc chọn file .gguf từ máy") { picking = true }
                }
                if let e = dl.error { Text(e).foregroundStyle(.red).font(.footnote).padding(.horizontal) }
                Text("Nên dùng Wi-Fi và giữ app mở khi đang tải.").font(.footnote).foregroundStyle(.secondary)
                Spacer()
            }
            .toolbar { Button { showSettings = true } label: { Image(systemName: "gearshape") } }
            .sheet(isPresented: $showSettings) { SettingsView(vm: vm) }
            .fileImporter(isPresented: $picking, allowedContentTypes: [.data]) { r in
                if case .success(let u) = r { dl.importFile(u) }
            }
        }
    }
}

// MARK: - Chat
struct ChatView: View {
    @ObservedObject var vm: ChatVM
    @ObservedObject var speaker: Speaker
    @ObservedObject var rec: Recognizer
    @State private var showSettings = false
    @State private var showPhotos = false
    @State private var showCamera = false
    @State private var showFiles = false
    @State private var photoItems: [PhotosPickerItem] = []
    @FocusState private var focused: Bool

    init(vm: ChatVM) { self.vm = vm; self.speaker = vm.speaker; self.rec = vm.recognizer }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                ScrollViewReader { proxy in
                    ScrollView {
                        LazyVStack(spacing: 10) {
                            if vm.messages.isEmpty {
                                Text("Hỏi gì cũng được — AI chạy ngay trên máy bạn.")
                                    .foregroundStyle(.secondary).padding(.top, 80)
                            }
                            ForEach(vm.messages) { m in Bubble(msg: m, speaker: speaker).id(m.id) }
                        }.padding()
                    }
                    .onChange(of: vm.messages.last?.text) { _, _ in
                        if let id = vm.messages.last?.id { proxy.scrollTo(id, anchor: .bottom) }
                    }
                    .scrollDismissesKeyboard(.interactively)
                }
                Divider()
                if !vm.pending.isEmpty || vm.processing > 0 {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 8) {
                            ForEach(vm.pending) { a in AttachChip(a: a) { vm.removePending(a) } }
                            if vm.processing > 0 { ProgressView().padding(.horizontal, 12) }
                        }.padding(.horizontal, 10).padding(.top, 8)
                    }
                }
                HStack(alignment: .bottom, spacing: 8) {
                    Menu {
                        Button { showPhotos = true } label: { Label("Chọn ảnh", systemImage: "photo") }
                        Button { showCamera = true } label: { Label("Chụp ảnh", systemImage: "camera") }
                        Button { showFiles = true } label: { Label("Chọn tệp", systemImage: "doc") }
                    } label: {
                        Image(systemName: "plus.circle.fill").font(.system(size: 34)).foregroundStyle(.gray)
                    }
                    Button { vm.toggleMic() } label: {
                        Image(systemName: rec.isRecording ? "stop.circle.fill" : "mic.circle.fill")
                            .font(.system(size: 34)).foregroundStyle(rec.isRecording ? .red : .accentColor)
                    }
                    TextField(rec.isRecording ? "Đang nghe…" : "Nhập câu hỏi", text: $vm.input, axis: .vertical)
                        .lineLimit(1...5).textFieldStyle(.roundedBorder).focused($focused)
                    if vm.isGenerating {
                        Button { vm.stop() } label: { Image(systemName: "stop.circle.fill").font(.system(size: 34)) }
                    } else {
                        Button { vm.send(); focused = false } label: {
                            Image(systemName: "arrow.up.circle.fill").font(.system(size: 34))
                        }.disabled(vm.processing > 0 ||
                                   (vm.input.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && vm.pending.isEmpty))
                    }
                }.padding(10)
            }
            .navigationTitle("Gemma Chat").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button { vm.newChat() } label: { Image(systemName: "square.and.pencil") }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button { showSettings = true } label: { Image(systemName: "gearshape") }
                }
            }
            .sheet(isPresented: $showSettings) { SettingsView(vm: vm) }
            .photosPicker(isPresented: $showPhotos, selection: $photoItems, maxSelectionCount: 4, matching: .images)
            .onChange(of: photoItems) { _, items in
                guard !items.isEmpty else { return }
                Task { await vm.addPhotos(items); photoItems = [] }
            }
            .fullScreenCover(isPresented: $showCamera) {
                CameraPicker { vm.addImage($0, name: "Ảnh chụp") }.ignoresSafeArea()
            }
            .fileImporter(isPresented: $showFiles, allowedContentTypes: [.item], allowsMultipleSelection: true) { r in
                if case .success(let urls) = r { vm.addFiles(urls) }
            }
            .alert("Không đính kèm được", isPresented: Binding(get: { vm.attachError != nil },
                                                                 set: { if !$0 { vm.attachError = nil } })) {
                Button("OK", role: .cancel) {}
            } message: { Text(vm.attachError ?? "") }
            .alert("Cần quyền micro và nhận dạng giọng nói trong Cài đặt iPhone.", isPresented: $rec.denied) {
                Button("OK", role: .cancel) {}
            }
        }
    }
}

struct Bubble: View {
    let msg: ChatMessage
    @ObservedObject var speaker: Speaker
    var isUser: Bool { msg.role == "user" }

    var body: some View {
        HStack {
            if isUser { Spacer(minLength: 40) }
            VStack(alignment: .leading, spacing: 6) {
                if let atts = msg.attachments, !atts.isEmpty {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 6) {
                            ForEach(atts) { a in
                                if let d = a.thumb, let ui = UIImage(data: d) {
                                    Image(uiImage: ui).resizable().scaledToFill()
                                        .frame(width: 72, height: 72).clipShape(RoundedRectangle(cornerRadius: 8))
                                } else {
                                    Label(a.name, systemImage: "doc.text").font(.footnote).lineLimit(1)
                                        .padding(8).background(.black.opacity(0.12))
                                        .clipShape(RoundedRectangle(cornerRadius: 8))
                                }
                            }
                        }
                    }
                }
                if msg.text.isEmpty { ProgressView() } else { Text(attributed) }
                if !isUser && !msg.text.isEmpty {
                    HStack(spacing: 16) {
                        Button { speaker.speaking ? speaker.stop() : speaker.speak(msg.text) } label: {
                            Image(systemName: speaker.speaking ? "speaker.slash" : "speaker.wave.2")
                        }
                        Button { UIPasteboard.general.string = msg.text } label: { Image(systemName: "doc.on.doc") }
                    }.font(.footnote).foregroundStyle(.secondary)
                }
            }
            .padding(12)
            .background(isUser ? Color.accentColor : Color(.secondarySystemBackground))
            .foregroundStyle(isUser ? Color.white : Color.primary)
            .clipShape(RoundedRectangle(cornerRadius: 16))
            .textSelection(.enabled)
            if !isUser { Spacer(minLength: 40) }
        }
    }

    var attributed: AttributedString {
        (try? AttributedString(markdown: msg.text,
            options: .init(interpretedSyntax: .inlineOnlyPreservingWhitespace))) ?? AttributedString(msg.text)
    }
}

// MARK: - Cài đặt
struct SettingsView: View {
    @ObservedObject var vm: ChatVM
    @Environment(\.dismiss) private var dismiss
    @AppStorage("systemPrompt") private var systemPrompt = Defaults.system
    @AppStorage("autoSpeak") private var autoSpeak = false
    @AppStorage("autoSendVoice") private var autoSendVoice = true
    @AppStorage("modelURL") private var modelURL = Defaults.modelURL
    @AppStorage("hfToken") private var hfToken = ""

    var body: some View {
        NavigationStack {
            Form {
                Section("Giọng nói") {
                    Toggle("Tự đọc câu trả lời (tiếng Việt)", isOn: $autoSpeak)
                    Toggle("Bấm mic lần 2 là gửi luôn", isOn: $autoSendVoice)
                }
                Section("Vai trò của AI") {
                    TextEditor(text: $systemPrompt).frame(minHeight: 100)
                    Button("Khôi phục mặc định") { systemPrompt = Defaults.system }
                }
                Section("Mô hình") {
                    TextField("Link .gguf", text: $modelURL, axis: .vertical).font(.footnote)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                    SecureField("Token Hugging Face (nếu cần)", text: $hfToken)
                    if ModelStore.exists {
                        LabeledContent("Dung lượng", value: ModelStore.sizeText)
                        Button("Xóa mô hình", role: .destructive) { vm.deleteModel(); dismiss() }
                    }
                }
            }
            .navigationTitle("Cài đặt").navigationBarTitleDisplayMode(.inline)
            .toolbar { Button("Xong") { dismiss() } }
        }
    }
}


// MARK: - Đính kèm
struct AttachChip: View {
    let a: Attachment
    let onRemove: () -> Void
    var body: some View {
        HStack(spacing: 6) {
            if let d = a.thumb, let ui = UIImage(data: d) {
                Image(uiImage: ui).resizable().scaledToFill().frame(width: 40, height: 40)
                    .clipShape(RoundedRectangle(cornerRadius: 6))
            } else {
                Image(systemName: "doc.text.fill").font(.title3).foregroundStyle(.secondary)
            }
            Text(a.name).font(.footnote).lineLimit(1).frame(maxWidth: 110, alignment: .leading)
            Button(action: onRemove) { Image(systemName: "xmark.circle.fill").foregroundStyle(.secondary) }
        }
        .padding(6).background(Color(.secondarySystemBackground)).clipShape(RoundedRectangle(cornerRadius: 10))
    }
}

struct CameraPicker: UIViewControllerRepresentable {
    var onImage: (UIImage) -> Void
    @Environment(\.dismiss) private var dismiss

    func makeUIViewController(context: Context) -> UIImagePickerController {
        let p = UIImagePickerController()
        p.sourceType = UIImagePickerController.isSourceTypeAvailable(.camera) ? .camera : .photoLibrary
        p.delegate = context.coordinator
        return p
    }
    func updateUIViewController(_ vc: UIImagePickerController, context: Context) {}
    func makeCoordinator() -> Coordinator { Coordinator(self) }

    final class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        let parent: CameraPicker
        init(_ p: CameraPicker) { parent = p }
        func imagePickerController(_ picker: UIImagePickerController,
                                   didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
            if let img = info[.originalImage] as? UIImage { parent.onImage(img) }
            parent.dismiss()
        }
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) { parent.dismiss() }
    }
}
