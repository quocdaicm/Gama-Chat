import Foundation
import SwiftUI
import PhotosUI

struct ChatMessage: Identifiable, Codable, Equatable {
    var id = UUID()
    var role: String   // "user" | "model"
    var text: String
    var attachments: [Attachment]? = nil
}

enum Defaults {
    static let modelURL = "https://huggingface.co/unsloth/gemma-3n-E2B-it-GGUF/resolve/main/gemma-3n-E2B-it-Q4_K_M.gguf"
    static let system = "Bạn là trợ lý AI thân thiện. Luôn trả lời bằng tiếng Việt, ngắn gọn, rõ ràng, trừ khi người dùng yêu cầu ngôn ngữ khác. Khi có nội dung tệp hoặc kết quả phân tích ảnh đính kèm, hãy dựa vào đó để trả lời và không bịa thêm."
}

@MainActor
final class ChatVM: ObservableObject {
    enum Phase: Equatable { case needModel, loading, ready, failed(String) }

    @Published var phase: Phase = .needModel
    @Published var messages: [ChatMessage] = []
    @Published var input = ""
    @Published var isGenerating = false
    @Published var pending: [Attachment] = []
    @Published var processing = 0
    @Published var attachError: String?

    let engine = LlamaEngine()
    let downloader = ModelDownloader()
    let speaker = Speaker()
    let recognizer = Recognizer()

    private var saveURL: URL { ModelStore.dir.appendingPathComponent("chat.json") }
    private var ud: UserDefaults { .standard }

    init() {
        if let d = try? Data(contentsOf: saveURL),
           let m = try? JSONDecoder().decode([ChatMessage].self, from: d) { messages = m }
        downloader.onFinished = { [weak self] in Task { @MainActor in self?.loadModel() } }
        if ModelStore.exists { loadModel() }
    }

    func loadModel() {
        phase = .loading
        Task {
            do { try await engine.load(path: ModelStore.url.path); phase = .ready }
            catch { phase = .failed(error.localizedDescription) }
        }
    }

    func startDownload() {
        downloader.start(urlString: ud.string(forKey: "modelURL") ?? Defaults.modelURL,
                         token: ud.string(forKey: "hfToken") ?? "")
    }

    func deleteModel() {
        stop(); engine.unload(); ModelStore.delete(); phase = .needModel
    }

    func newChat() { stop(); messages = []; pending = []; save() }

    // MARK: Đính kèm
    func addImage(_ img: UIImage, name: String) {
        processing += 1
        Task {
            let (up, thumb) = await Task.detached(priority: .userInitiated) { () -> (UIImage, Data?) in
                let up = img.normalized(maxDim: 2048)
                let t = up.preparingThumbnail(of: CGSize(width: 160, height: 160))?.jpegData(compressionQuality: 0.6)
                return (up, t)
            }.value
            let text = await ImageAnalyzer.analyze(up)
            pending.append(Attachment(kind: "image", name: name, text: text, thumb: thumb))
            processing -= 1
        }
    }

    func addPhotos(_ items: [PhotosPickerItem]) async {
        for (i, item) in items.enumerated() {
            if let data = try? await item.loadTransferable(type: Data.self), let img = UIImage(data: data) {
                addImage(img, name: "Ảnh \(pending.count + i + 1)")
            }
        }
    }

    func addFiles(_ urls: [URL]) {
        for url in urls {
            processing += 1
            Task {
                do {
                    let t = try await FileReader.extract(url)
                    pending.append(Attachment(kind: "file", name: url.lastPathComponent, text: t))
                } catch { attachError = "\(url.lastPathComponent): \(error.localizedDescription)" }
                processing -= 1
            }
        }
    }

    func removePending(_ a: Attachment) { pending.removeAll { $0.id == a.id } }

    // MARK: Gửi
    private func promptContent(_ m: ChatMessage, full: Bool) -> String {
        guard let atts = m.attachments, !atts.isEmpty else { return m.text }
        var budget = full ? 10_000 : 2_500
        var parts = [String]()
        for a in atts {
            var t = a.text
            if t.count > budget { t = String(t.prefix(max(budget, 0))) + "\n[...đã cắt bớt]" }
            budget -= t.count
            let head = a.kind == "image"
                ? "[Ảnh đính kèm: \(a.name) — hệ thống đã phân tích tự động; bạn không nhìn thấy ảnh, chỉ dựa vào kết quả này]"
                : "[Tệp đính kèm: \(a.name)]"
            parts.append(head + "\n" + t)
        }
        return parts.joined(separator: "\n\n") + "\n\n" + m.text
    }

    func send(_ override: String? = nil) {
        var t = (override ?? input).trimmingCharacters(in: .whitespacesAndNewlines)
        let atts = pending
        guard !t.isEmpty || !atts.isEmpty, !isGenerating, processing == 0, phase == .ready else { return }
        if t.isEmpty {
            t = atts.contains { $0.kind == "file" } ? "Hãy tóm tắt nội dung tệp đính kèm." : "Hãy mô tả và giải thích nội dung ảnh này."
        }
        speaker.stop()
        input = ""; pending = []
        messages.append(.init(role: "user", text: t, attachments: atts.isEmpty ? nil : atts))
        messages.append(.init(role: "model", text: ""))
        let idx = messages.count - 1
        let lastUser = idx - 1
        let history = messages.dropLast().enumerated().map { (i, m) in
            (role: m.role, content: promptContent(m, full: i == lastUser))
        }
        isGenerating = true
        let system = ud.string(forKey: "systemPrompt") ?? Defaults.system
        engine.generate(history: history, system: system, onToken: { [weak self] piece in
            MainActor.assumeIsolated { self?.messages[idx].text += piece }
        }, onDone: { [weak self] err in
            MainActor.assumeIsolated {
                guard let self else { return }
                self.isGenerating = false
                if let err { self.messages[idx].text += "\n\n⚠️ \(err.localizedDescription)" }
                if self.messages[idx].text.isEmpty { self.messages[idx].text = "(không có câu trả lời)" }
                self.save()
                if self.ud.bool(forKey: "autoSpeak") { self.speaker.speak(self.messages[idx].text) }
            }
        })
    }

    func stop() { engine.cancel(); speaker.stop() }

    func toggleMic() {
        if recognizer.isRecording {
            recognizer.stop()
            if ud.object(forKey: "autoSendVoice") == nil || ud.bool(forKey: "autoSendVoice") { send() }
        } else {
            speaker.stop()
            recognizer.start { [weak self] text in self?.input = text }
        }
    }

    private func save() {
        if let d = try? JSONEncoder().encode(messages) { try? d.write(to: saveURL) }
    }
}
