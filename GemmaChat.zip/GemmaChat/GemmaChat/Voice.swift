import Foundation
import AVFoundation
import Speech

/// Đọc câu trả lời bằng giọng tiếng Việt có sẵn của iOS.
final class Speaker: NSObject, ObservableObject, AVSpeechSynthesizerDelegate {
    @Published var speaking = false
    private let synth = AVSpeechSynthesizer()

    override init() { super.init(); synth.delegate = self }

    static func clean(_ t: String) -> String {
        t.replacingOccurrences(of: "```", with: " ")
         .replacingOccurrences(of: "`", with: "")
         .replacingOccurrences(of: "*", with: "")
         .replacingOccurrences(of: "#", with: "")
         .replacingOccurrences(of: "_", with: " ")
    }

    func speak(_ text: String) {
        stop()
        let t = Speaker.clean(text).trimmingCharacters(in: .whitespacesAndNewlines)
        guard !t.isEmpty else { return }
        try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .spokenAudio)
        try? AVAudioSession.sharedInstance().setActive(true)
        let u = AVSpeechUtterance(string: t)
        u.voice = AVSpeechSynthesisVoice(language: "vi-VN") ?? AVSpeechSynthesisVoice(language: Locale.current.identifier)
        u.rate = AVSpeechUtteranceDefaultSpeechRate
        synth.speak(u)
        speaking = true
    }

    func stop() { synth.stopSpeaking(at: .immediate); speaking = false }

    func speechSynthesizer(_ s: AVSpeechSynthesizer, didFinish _: AVSpeechUtterance) {
        DispatchQueue.main.async { self.speaking = false }
    }
    func speechSynthesizer(_ s: AVSpeechSynthesizer, didCancel _: AVSpeechUtterance) {
        DispatchQueue.main.async { self.speaking = false }
    }
}

/// Nhập bằng giọng nói (tiếng Việt).
final class Recognizer: ObservableObject {
    @Published var isRecording = false
    @Published var denied = false
    private let recognizer = SFSpeechRecognizer(locale: Locale(identifier: "vi-VN"))
    private let engine = AVAudioEngine()
    private var request: SFSpeechAudioBufferRecognitionRequest?
    private var task: SFSpeechRecognitionTask?

    func start(onText: @escaping (String) -> Void) {
        SFSpeechRecognizer.requestAuthorization { status in
            AVAudioApplication.requestRecordPermission { granted in
                DispatchQueue.main.async {
                    guard status == .authorized, granted else { self.denied = true; return }
                    self.begin(onText)
                }
            }
        }
    }

    private func begin(_ onText: @escaping (String) -> Void) {
        guard let recognizer, recognizer.isAvailable else { denied = true; return }
        do {
            let s = AVAudioSession.sharedInstance()
            try s.setCategory(.playAndRecord, mode: .measurement, options: [.duckOthers, .defaultToSpeaker])
            try s.setActive(true, options: .notifyOthersOnDeactivation)
            let req = SFSpeechAudioBufferRecognitionRequest()
            req.shouldReportPartialResults = true
            if recognizer.supportsOnDeviceRecognition { req.requiresOnDeviceRecognition = true }
            request = req
            let input = engine.inputNode
            input.removeTap(onBus: 0)
            input.installTap(onBus: 0, bufferSize: 1024, format: input.outputFormat(forBus: 0)) { buf, _ in
                req.append(buf)
            }
            engine.prepare(); try engine.start()
            isRecording = true
            task = recognizer.recognitionTask(with: req) { [weak self] result, error in
                if let r = result {
                    let t = r.bestTranscription.formattedString
                    DispatchQueue.main.async { onText(t) }
                }
                if error != nil || result?.isFinal == true {
                    DispatchQueue.main.async { self?.stop() }
                }
            }
        } catch { stop() }
    }

    func stop() {
        if engine.isRunning { engine.stop(); engine.inputNode.removeTap(onBus: 0) }
        request?.endAudio(); task?.cancel()
        request = nil; task = nil
        isRecording = false
    }
}
