import Foundation
import UIKit

enum ModelStore {
    static var dir: URL {
        let d = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? FileManager.default.createDirectory(at: d, withIntermediateDirectories: true)
        return d
    }
    static var url: URL { dir.appendingPathComponent("model.gguf") }
    static var exists: Bool { FileManager.default.fileExists(atPath: url.path) }
    static var sizeText: String {
        let s = (try? FileManager.default.attributesOfItem(atPath: url.path)[.size] as? Int64) ?? 0
        return ByteCountFormatter.string(fromByteCount: s ?? 0, countStyle: .file)
    }
    static func delete() { try? FileManager.default.removeItem(at: url) }
    static func exclude() {
        var u = url; var v = URLResourceValues(); v.isExcludedFromBackup = true
        try? u.setResourceValues(v)
    }
}

final class ModelDownloader: NSObject, ObservableObject, URLSessionDownloadDelegate {
    @Published var progress: Double = 0
    @Published var received: Int64 = 0
    @Published var total: Int64 = 0
    @Published var isDownloading = false
    @Published var error: String?
    var onFinished: (() -> Void)?

    private var session: URLSession!
    private var task: URLSessionDownloadTask?
    private var resumeData: Data?
    private var lastUI = Date.distantPast

    override init() {
        super.init()
        session = URLSession(configuration: .default, delegate: self, delegateQueue: nil)
    }

    func start(urlString: String, token: String) {
        guard let u = URL(string: urlString) else { error = "Link mô hình không hợp lệ."; return }
        error = nil; isDownloading = true
        UIApplication.shared.isIdleTimerDisabled = true
        if let rd = resumeData {
            task = session.downloadTask(withResumeData: rd); resumeData = nil
        } else {
            var req = URLRequest(url: u)
            if !token.isEmpty { req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }
            task = session.downloadTask(with: req)
        }
        task?.resume()
    }

    func pause() {
        task?.cancel(byProducingResumeData: { [weak self] d in
            DispatchQueue.main.async { self?.resumeData = d; self?.isDownloading = false
                UIApplication.shared.isIdleTimerDisabled = false }
        })
    }

    func cancel() {
        task?.cancel(); resumeData = nil; isDownloading = false; progress = 0
        UIApplication.shared.isIdleTimerDisabled = false
    }

    func importFile(_ src: URL) {
        let access = src.startAccessingSecurityScopedResource()
        defer { if access { src.stopAccessingSecurityScopedResource() } }
        do {
            ModelStore.delete()
            try FileManager.default.copyItem(at: src, to: ModelStore.url)
            ModelStore.exclude()
            onFinished?()
        } catch { self.error = "Không chép được file: \(error.localizedDescription)" }
    }

    // MARK: delegate
    func urlSession(_ s: URLSession, downloadTask t: URLSessionDownloadTask, didWriteData _: Int64,
                    totalBytesWritten w: Int64, totalBytesExpectedToWrite e: Int64) {
        guard Date().timeIntervalSince(lastUI) > 0.3 else { return }
        lastUI = Date()
        DispatchQueue.main.async {
            self.received = w; self.total = e
            self.progress = e > 0 ? Double(w) / Double(e) : 0
        }
    }

    func urlSession(_ s: URLSession, downloadTask t: URLSessionDownloadTask, didFinishDownloadingTo loc: URL) {
        if let http = t.response as? HTTPURLResponse, http.statusCode != 200 {
            let msg = (http.statusCode == 401 || http.statusCode == 403)
                ? "Cần token Hugging Face (Cài đặt → Token) hoặc link không cho tải."
                : "Máy chủ trả lỗi \(http.statusCode)."
            DispatchQueue.main.async { self.error = msg; self.isDownloading = false
                UIApplication.shared.isIdleTimerDisabled = false }
            return
        }
        do {
            ModelStore.delete()
            try FileManager.default.moveItem(at: loc, to: ModelStore.url)
            ModelStore.exclude()
            DispatchQueue.main.async {
                self.isDownloading = false; self.progress = 1
                UIApplication.shared.isIdleTimerDisabled = false
                self.onFinished?()
            }
        } catch {
            DispatchQueue.main.async { self.error = error.localizedDescription; self.isDownloading = false }
        }
    }

    func urlSession(_ s: URLSession, task t: URLSessionTask, didCompleteWithError e: Error?) {
        guard let e = e as NSError?, e.code != NSURLErrorCancelled else { return }
        let rd = e.userInfo[NSURLSessionDownloadTaskResumeData] as? Data
        DispatchQueue.main.async {
            self.resumeData = rd
            self.error = "Tải bị ngắt: \(e.localizedDescription). Bấm Tải để tiếp tục."
            self.isDownloading = false
            UIApplication.shared.isIdleTimerDisabled = false
        }
    }
}
