import SwiftUI

enum Theme {
    static let violet = Color(red: 0.36, green: 0.24, blue: 0.96)
    static let cyan = Color(red: 0.12, green: 0.71, blue: 0.83)
    static let gradient = LinearGradient(colors: [violet, cyan], startPoint: .topLeading, endPoint: .bottomTrailing)
    static var backdrop: LinearGradient {
        LinearGradient(colors: [violet.opacity(0.16), cyan.opacity(0.08), Color(.systemBackground)],
                       startPoint: .top, endPoint: .bottom)
    }
}

/// Tia sáng 4 cánh (cùng công thức với icon).
struct Sparkle: Shape {
    func path(in rect: CGRect) -> Path {
        var p = Path()
        let c = CGPoint(x: rect.midX, y: rect.midY)
        let r = min(rect.width, rect.height) / 2
        let n = 120
        for i in 0..<n {
            let t = 2 * Double.pi * Double(i) / Double(n)
            let ct = cos(t), st = sin(t)
            let x = c.x + r * CGFloat(pow(abs(ct), 3) * (ct < 0 ? -1 : 1))
            let y = c.y + r * CGFloat(pow(abs(st), 3) * (st < 0 ? -1 : 1))
            if i == 0 { p.move(to: CGPoint(x: x, y: y)) } else { p.addLine(to: CGPoint(x: x, y: y)) }
        }
        p.closeSubpath()
        return p
    }
}

struct BubbleShape: Shape {
    func path(in r: CGRect) -> Path {
        let bodyH = r.height * 0.82
        var p = Path(roundedRect: CGRect(x: r.minX, y: r.minY, width: r.width, height: bodyH),
                     cornerRadius: bodyH * 0.3, style: .continuous)
        var t = Path()
        t.move(to: CGPoint(x: r.minX + r.width * 0.16, y: r.minY + bodyH - 1))
        t.addLine(to: CGPoint(x: r.minX + r.width * 0.10, y: r.maxY))
        t.addLine(to: CGPoint(x: r.minX + r.width * 0.36, y: r.minY + bodyH - 1))
        t.closeSubpath()
        p.addPath(t)
        return p
    }
}

struct LogoView: View {
    var size: CGFloat = 96
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: size * 0.225, style: .continuous).fill(Theme.gradient)
            BubbleShape().fill(Color.white)
                .frame(width: size * 0.62, height: size * 0.56).offset(y: -size * 0.02)
            Sparkle().fill(Theme.gradient)
                .frame(width: size * 0.30, height: size * 0.30).offset(y: -size * 0.07)
            Sparkle().fill(Color.white)
                .frame(width: size * 0.15, height: size * 0.15).offset(x: size * 0.32, y: -size * 0.33)
        }
        .frame(width: size, height: size)
        .shadow(color: Theme.violet.opacity(0.35), radius: size * 0.12, y: size * 0.06)
    }
}

struct AvatarMark: View {
    var size: CGFloat = 28
    var body: some View {
        ZStack {
            Circle().fill(Theme.gradient)
            Sparkle().fill(Color.white).frame(width: size * 0.5, height: size * 0.5)
        }.frame(width: size, height: size)
    }
}

struct PulsingLogo: View {
    @State private var on = false
    var body: some View {
        LogoView(size: 96)
            .scaleEffect(on ? 1.06 : 0.96)
            .animation(.easeInOut(duration: 0.9).repeatForever(autoreverses: true), value: on)
            .onAppear { on = true }
    }
}

struct TypingDots: View {
    @State private var on = false
    var body: some View {
        HStack(spacing: 5) {
            ForEach(0..<3, id: \.self) { i in
                Circle().fill(Theme.violet.opacity(0.7)).frame(width: 8, height: 8)
                    .scaleEffect(on ? 1 : 0.5)
                    .animation(.easeInOut(duration: 0.6).repeatForever().delay(Double(i) * 0.2), value: on)
            }
        }
        .padding(.vertical, 6)
        .onAppear { on = true }
    }
}

struct GradientButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.headline).foregroundStyle(.white)
            .frame(maxWidth: .infinity).padding(.vertical, 16)
            .background(Theme.gradient, in: Capsule())
            .shadow(color: Theme.violet.opacity(0.35), radius: 10, y: 5)
            .opacity(configuration.isPressed ? 0.85 : 1)
            .scaleEffect(configuration.isPressed ? 0.98 : 1)
    }
}
