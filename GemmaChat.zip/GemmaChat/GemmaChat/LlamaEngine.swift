import Foundation
import llama

enum LlamaError: LocalizedError {
    case loadModel, context, decode
    var errorDescription: String? {
        switch self {
        case .loadModel: return "Không nạp được mô hình (file hỏng hoặc thiếu RAM)."
        case .context: return "Không tạo được ngữ cảnh. Máy có thể thiếu RAM."
        case .decode: return "Lỗi khi AI xử lý câu hỏi."
        }
    }
}

final class LlamaEngine {
    private var model: OpaquePointer?
    private var ctx: OpaquePointer?
    private var vocab: OpaquePointer?
    private var sampler: UnsafeMutablePointer<llama_sampler>?
    private let nCtx: Int = 8192
    private let maxNew = 1024
    private let queue = DispatchQueue(label: "llama.engine", qos: .userInitiated)
    private let lock = NSLock()
    private var cancelled = false

    var isLoaded: Bool { model != nil && ctx != nil }

    func cancel() { lock.lock(); cancelled = true; lock.unlock() }
    private var isCancelled: Bool { lock.lock(); defer { lock.unlock() }; return cancelled }
    private func resetCancel() { lock.lock(); cancelled = false; lock.unlock() }

    // MARK: Load
    func load(path: String) async throws {
        try await withCheckedThrowingContinuation { (cont: CheckedContinuation<Void, Error>) in
            queue.async {
                do { try self.loadSync(path); cont.resume() }
                catch { cont.resume(throwing: error) }
            }
        }
    }

    private func loadSync(_ path: String) throws {
        unload()
        llama_backend_init()
        var mp = llama_model_default_params()
        #if targetEnvironment(simulator)
        mp.n_gpu_layers = 0
        #else
        mp.n_gpu_layers = 99
        #endif
        guard let m = llama_model_load_from_file(path, mp) else { throw LlamaError.loadModel }
        var cp = llama_context_default_params()
        cp.n_ctx = UInt32(nCtx)
        cp.n_batch = 512
        cp.n_ubatch = 512
        let threads = Int32(max(2, ProcessInfo.processInfo.activeProcessorCount - 2))
        cp.n_threads = threads
        cp.n_threads_batch = threads
        guard let c = llama_init_from_model(m, cp) else {
            llama_model_free(m); throw LlamaError.context
        }
        model = m; ctx = c
        vocab = llama_model_get_vocab(m)

        let chain = llama_sampler_chain_init(llama_sampler_chain_default_params())!
        llama_sampler_chain_add(chain, llama_sampler_init_top_k(40))
        llama_sampler_chain_add(chain, llama_sampler_init_top_p(0.95, 1))
        llama_sampler_chain_add(chain, llama_sampler_init_temp(0.7))
        llama_sampler_chain_add(chain, llama_sampler_init_dist(UInt32.random(in: 0...UInt32.max)))
        sampler = chain
    }

    func unload() {
        if let s = sampler { llama_sampler_free(s); sampler = nil }
        if let c = ctx { llama_free(c); ctx = nil }
        if let m = model { llama_model_free(m); model = nil }
        vocab = nil
    }

    // MARK: Prompt (định dạng chat của Gemma)
    private func format(_ msgs: [(role: String, content: String)], system: String) -> String {
        var out = ""
        for (i, m) in msgs.enumerated() {
            var content = m.content
            if i == 0, m.role == "user", !system.isEmpty { content = system + "\n\n" + content }
            out += "<start_of_turn>\(m.role)\n\(content)<end_of_turn>\n"
        }
        out += "<start_of_turn>model\n"
        return out
    }

    private func tokenize(_ text: String) -> [llama_token] {
        let len = Int32(text.utf8.count)
        var toks = [llama_token](repeating: 0, count: Int(len) + 16)
        var n = llama_tokenize(vocab, text, len, &toks, Int32(toks.count), true, true)
        if n < 0 {
            toks = [llama_token](repeating: 0, count: Int(-n))
            n = llama_tokenize(vocab, text, len, &toks, Int32(toks.count), true, true)
        }
        return Array(toks.prefix(Int(max(0, n))))
    }

    // MARK: Generate
    func generate(history: [(role: String, content: String)],
                  system: String,
                  onToken: @escaping (String) -> Void,
                  onDone: @escaping (Error?) -> Void) {
        resetCancel()
        queue.async {
            var err: Error?
            do { try self.run(history, system, onToken) } catch { err = error }
            DispatchQueue.main.async { onDone(err) }
        }
    }

    private func run(_ history: [(role: String, content: String)], _ system: String,
                     _ onToken: @escaping (String) -> Void) throws {
        guard let ctx, let sampler, let vocab else { throw LlamaError.context }

        var msgs = history
        var toks = tokenize(format(msgs, system: system))
        while toks.count > nCtx - maxNew, msgs.count > 1 {
            msgs.removeFirst()
            if msgs.first?.role == "model" { msgs.removeFirst() }
            toks = tokenize(format(msgs, system: system))
        }
        if toks.count > nCtx - 64 { toks = Array(toks.suffix(nCtx - 64)) }

        llama_memory_clear(llama_get_memory(ctx), true)
        llama_sampler_reset(sampler)

        var i = 0
        while i < toks.count {
            if isCancelled { return }
            let end = min(i + 512, toks.count)
            var chunk = Array(toks[i..<end])
            let rc = chunk.withUnsafeMutableBufferPointer {
                llama_decode(ctx, llama_batch_get_one($0.baseAddress, Int32($0.count)))
            }
            if rc != 0 { throw LlamaError.decode }
            i = end
        }

        var pending = [UInt8]()
        var pos = toks.count
        var produced = 0
        while pos < nCtx - 1, produced < maxNew, !isCancelled {
            var tok = llama_sampler_sample(sampler, ctx, -1)
            if llama_vocab_is_eog(vocab, tok) { break }

            var buf = [CChar](repeating: 0, count: 128)
            let n = llama_token_to_piece(vocab, tok, &buf, 128, 0, true)
            if n > 0 {
                pending += buf.prefix(Int(n)).map { UInt8(bitPattern: $0) }
                if let s = String(data: Data(pending), encoding: .utf8) {
                    pending.removeAll()
                    DispatchQueue.main.async { onToken(s) }
                } else if pending.count > 8 {
                    let s = String(decoding: pending, as: UTF8.self)
                    pending.removeAll()
                    DispatchQueue.main.async { onToken(s) }
                }
            }
            let rc = withUnsafeMutablePointer(to: &tok) {
                llama_decode(ctx, llama_batch_get_one($0, 1))
            }
            if rc != 0 { throw LlamaError.decode }
            pos += 1; produced += 1
        }
    }
}
